//programa principal

import 'package:flutter/cupertino.dart';
import 'package:aprendendoflutter/olamundo.dart';

void main(){
runApp(OlaMundoApp());
}