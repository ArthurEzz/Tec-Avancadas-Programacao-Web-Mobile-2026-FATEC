import 'package:flutter/material.dart';

class EntradaAplicativo extends StatelessWidget{
  @override 
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Segundo Projeto Flutter',
      home: EntradaPagina(),
    );
  }
}

class EntradaPagina extends StatefulWidget{
    @override
  State<StatefulWidget> createState() {
  return EntradaEstado();
  }
}

class EntradaEstado extends State<EntradaPagina>{

  String nome = '';
  int ano = 0;

TextEditingController nomeController = TextEditingController();
TextEditingController idadeController = TextEditingController();

  void Enviar(){
    int idade = int.tryParse(idadeController.text) ?? 0;
    setState(() {
      nome = nomeController.text;
      ano = 2026 - idade;
      


    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('AprendendoEntradas'),
      ),
      body: Padding(
        padding: EdgeInsets.all(100),
        child: Column(
        children: [

          TextField(
            decoration: InputDecoration(
              labelText: 'Quantos anos você tem?',
            ),
            controller: idadeController,
            ),

            SizedBox(height: 50,),

            TextField(
            decoration: InputDecoration(
              labelText: 'Qual o seu nome?',
            ),
            controller: nomeController,
            
            ),

          SizedBox(height: 50,),

          TextField(
            obscureText: true,
            decoration: InputDecoration(
              labelText: 'Senha:',
            ),
          ),

          SizedBox(height: 30,),

          Text('Boa Tarde $nome'),
          Text('Você nasceu no ano $ano'),

          SizedBox(height: 30,),

          ElevatedButton(
            onPressed: Enviar,
             child: Text("Enviar"),
             )

        ],
      ),
    ),
    );
      }
}