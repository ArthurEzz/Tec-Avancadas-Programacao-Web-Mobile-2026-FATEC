//programa principal
import 'package:entradas/entrada.dart';
import 'package:flutter/material.dart';

void main(){
runApp(EntradaAplicativo());
}