import 'package:flutter/material.dart';

class EntradaAplicativo extends StatelessWidget{
  @override 
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Segundo Projeto Flutter',
      home: EntradaPagina(),
    );
  }
}

class EntradaPagina extends StatefulWidget{
    @override
  State<StatefulWidget> createState() {
  return EntradaEstado();
  }
}

class EntradaEstado extends State<EntradaPagina>{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('AprendendoEntradas'),
      ),
      body: Padding(
        padding: EdgeInsets.all(100),
        child: Column(
        children: [

          TextField(
            decoration: InputDecoration(
              labelText: 'Quantos anos você tem?',
            ),
            ),

            SizedBox(height: 50,),

            TextField(
            decoration: InputDecoration(
              labelText: 'Qual o seu nome?',
            ),
            ),
        ],
      ),
    ),
    );
      }
}