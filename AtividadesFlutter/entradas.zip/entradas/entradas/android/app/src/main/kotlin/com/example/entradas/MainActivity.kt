package com.example.entradas

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
