# Generated code do not commit.
file(TO_CMAKE_PATH "D:\\SDKs\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "D:\\1_AMS-DS\\TAPWMobile\\ProjetosFlutters\\quarto_trabalho_parcial" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=D:\\SDKs\\flutter"
  "PROJECT_DIR=D:\\1_AMS-DS\\TAPWMobile\\ProjetosFlutters\\quarto_trabalho_parcial"
  "FLUTTER_ROOT=D:\\SDKs\\flutter"
  "FLUTTER_EPHEMERAL_DIR=D:\\1_AMS-DS\\TAPWMobile\\ProjetosFlutters\\quarto_trabalho_parcial\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=D:\\1_AMS-DS\\TAPWMobile\\ProjetosFlutters\\quarto_trabalho_parcial"
  "FLUTTER_TARGET=D:\\1_AMS-DS\\TAPWMobile\\ProjetosFlutters\\quarto_trabalho_parcial\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDQuMA==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049NTU5ZmZhM2Y3NQ==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049NGM1MjVkYWM1ZQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMi4w"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=D:\\1_AMS-DS\\TAPWMobile\\ProjetosFlutters\\quarto_trabalho_parcial\\.dart_tool\\package_config.json"
)
